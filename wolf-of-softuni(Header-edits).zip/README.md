Software University Web Fundamentals Team Project by Team Voss: The Wolf of SoftUni  
Check it out at: https://dilyanastolarova.github.io/wolf-of-softuni/
